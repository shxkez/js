const Discord = require('discord.js')
module.exports.run = async (bot, message, args, gen) => {
    let depo = new Discord.MessageEmbed()
    .setTitle('Depo World Locks!')
    .setColor(bot.color)
    .setThumbnail('https://media.discordapp.net/attachments/1133351643115692082/1142237327649935380/DEPO_WORLD.png ')
    .setDescription('**Depo World Locks!**')
    .addField('📚 Depo In World: UMIVDZ','SEND A SCREENSHOT TO OWNER')
      .setFooter('Deposit to The Bot')
    .setTimestamp()

    message.author.send(depo)
       setTimeout(() => message.delete(), 100);
    }
    
module.exports.help = {
    name: 'depo',
    aliases: []
}