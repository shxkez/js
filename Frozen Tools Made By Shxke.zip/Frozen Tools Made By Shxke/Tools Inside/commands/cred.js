const discord = require('discord.js'); //Define the discord.js module
const client = new discord.Client(); //Creating discord.js client (constructor)
const disbut = require('discord-buttons');
disbut(client);

module.exports.run = async (bot, message, args, gen) => {
  let button = new disbut.MessageButton()
  .setStyle('url')
  .setURL('https://discord.gg/XUmN66mFkH')
  .setLabel('Join Store Here')

    message.channel.send('Bot Owned By: Shxke');
    message.channel.send('Bot Coded By: MrCm');
    message.channel.send('MarketPlace: Below!', button)
  }

module.exports.help = {
name: 'cred',
aliases: []
}
