const Discord = require('discord.js')
module.exports.run = async (bot, message, args, gen) => {
    let embed = new Discord.MessageEmbed()
    .setTitle('Shxke Commands')
    .setColor(bot.color)
    .setThumbnail('https://share.creavite.co/xRW0r8tXLoUKpwVg.gif')
    .setDescription('**Generator Commands**')
    .addField('📚 !help','Shows All Available Commands')
    .addField('📟 !gen (service)','Generates An Account')
    .addField('📊 !stock','Shows A List Of All  Accounts in Stock')
    .addField('💰 !Buy','Open an Buy Ticket to Buy the Script or the Bot')
      .addField('📑 !dev','Show u The Credits Who made the Bot')
      .setFooter('Made by MrCm ','')
    .setTimestamp()
       message.channel.send(embed)
       setTimeout(() => message.delete(), 100);
    }
    
module.exports.help = {
    name: 'help',
    aliases: []
}